package com.example.macstudent.melody;

import android.media.MediaPlayer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.concurrent.TimeUnit;

public class SongsActivity extends AppCompatActivity {

    MediaPlayer mediaPlayer;
    private int startTime = 0;
    private int finalTime = 0;
    private Handler myHandler = new Handler();
    private int seekTime = 5000;
    ImageButton img_play,img_pause,img_forword,img_rewind,img_stop;
    TextView txt_timer;
    SeekBar seekBar;
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        mediaPlayer.stop();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_songs);
        img_forword = (ImageButton)findViewById(R.id.img_forword);
        img_pause = (ImageButton)findViewById(R.id.img_pause);
        img_play = (ImageButton)findViewById(R.id.img_play);
        img_rewind = (ImageButton)findViewById(R.id.img_rewind);
        img_stop = (ImageButton)findViewById(R.id.img_stop);
        seekBar = (SeekBar)findViewById(R.id.seekBar);
        txt_timer = (TextView)findViewById(R.id.txt_time);

        mediaPlayer = MediaPlayer.create(getApplicationContext(),
                R.raw.hangouts);
        finalTime = mediaPlayer.getDuration();
        startTime = mediaPlayer.getCurrentPosition();
        seekBar.setMax((int) finalTime);

        img_play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mediaPlayer.start();
                seekBar.setProgress((int)startTime);
                myHandler.postDelayed(UpdateSongTime,100);

            }
        });
        img_pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mediaPlayer.pause();

            }
        });
        img_rewind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int currentPosition = mediaPlayer.getCurrentPosition();
                if(currentPosition - seekTime >= 0){
                    mediaPlayer.seekTo(currentPosition - seekTime);
                }else{
                    mediaPlayer.seekTo(0);
                }
            }
        });
        img_forword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int currentPosition = mediaPlayer.getCurrentPosition();
                if(currentPosition + seekTime <= mediaPlayer.getDuration()){
                    mediaPlayer.seekTo(currentPosition + seekTime);
                }else{
                    mediaPlayer.seekTo(mediaPlayer.getDuration());
                }

            }
        });
        img_stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // mediaPlayer.stop();
                mediaPlayer.seekTo(finalTime);
            }
        });



    }
    private Runnable UpdateSongTime = new Runnable() {
        public void run() {
            startTime = mediaPlayer.getCurrentPosition();
            txt_timer.setText(String.format("%d min, %d sec",
                    TimeUnit.MILLISECONDS.toMinutes((long) startTime),
                    TimeUnit.MILLISECONDS.toSeconds((long) startTime) -
                            TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.
                                    toMinutes((long) startTime)))
            );
            seekBar.setProgress((int)startTime);
            myHandler.postDelayed(this, 100);
        }
    };
}
