package com.example.macstudent.melody;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by macstudent on 2018-04-23.
 */

public class MusicAdapter extends BaseAdapter {
    int album[] = {R.drawable.mp3,R.drawable.mp3,R.drawable.mp3,R.drawable.mp3};
    String title[] = {"Romantic Lamhe","Retro 90's","Crazy HipHop","Jazz Rythems"};
    ImageView album_img;
    TextView album_title;
    Context context;
    LayoutInflater layoutInflater;
    View album_view;
    MusicAdapter(Context context){
        this.context = context;
        layoutInflater = (LayoutInflater.from(context));
    }
    @Override
    public int getCount() {
        return album.length;
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        album_view = layoutInflater.inflate(R.layout.grid_item_list,null);
        album_img = album_view.findViewById(R.id.img_album);
        album_img.setImageResource(album[i]);
        album_title = album_view.findViewById(R.id.txt_title);
        album_title.setText(title[i]);

        return album_view;
    }
}