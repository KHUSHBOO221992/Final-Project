package com.example.macstudent.melody;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

public class MusicActivity extends AppCompatActivity {
    GridView grid_album;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music);
        grid_album = (GridView)findViewById(R.id.grid_album);
        grid_album.setAdapter(new MusicAdapter(this));
        grid_album.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent audioIntent = new Intent(getApplicationContext(),SongsActivity.class);


                startActivity(audioIntent);
            }
        });

    }
}